export const metadata = {
  title: 'TimeGPS Pro'
};

export default function RootLayout({ children }) {
  return (
    <html lang="th">
      <body>{children}</body>
    </html>
  );
}
